import streamlit as st 
st.set_page_config(page_title="Image Processing",page_icon="✨",layout="wide")
st.title("Image Processing✨")
st.subheader("Welcome , we are providing an interactive platform to process your images and try some other features  of computer vision")
st.sidebar.title("Select a page")

   







































