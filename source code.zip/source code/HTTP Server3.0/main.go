package main

import (
	"net/http"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
)

// UserCredentials holds the incoming username and password
type UserCredentials struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// Claims holds the JWT claims
type Claims struct {
	Username string `json:"username"`
	jwt.StandardClaims
}

// Dummy data for demonstration purposes
var users = map[string]string{
	"user1": "password1",
	"user2": "password2",
}

var jwtSecret = []byte("your_secret_key")

// TokenResponse holds the token response
type TokenResponse struct {
	AccessToken string `json:"access_token"`
}

func main() {
	router := gin.Default()

	// Define the /authenticate endpoint
	router.POST("/authenticate", func(c *gin.Context) {
		var credentials UserCredentials

		// Bind the JSON payload to the UserCredentials struct
		if err := c.ShouldBindJSON(&credentials); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request"})
			return
		}

		// Check if the username exists
		if _, exists := users[credentials.Username]; !exists {
			c.JSON(http.StatusNotFound, gin.H{"error_code": "5001", "error_message": "User is unknown (DIAMETER_ERROR_USER_UNKNOWN)"})
			return
		}

		// Verify the user credentials
		if password, ok := users[credentials.Username]; ok && password == credentials.Password {
			// Create the JWT token
			expirationTime := time.Now().Add(1 * time.Hour)
			claims := &Claims{
				Username: credentials.Username,
				StandardClaims: jwt.StandardClaims{
					ExpiresAt: expirationTime.Unix(),
				},
			}

			token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
			tokenString, err := token.SignedString(jwtSecret)
			if err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not generate token"})
				return
			}

			// Return the token
			c.JSON(http.StatusOK, TokenResponse{AccessToken: tokenString})
		} else {
			c.JSON(http.StatusForbidden, gin.H{"error_code": "4001", "error_message": "Authentication rejected (DIAMETER_AUTHENTICATION_REJECTED)"})
		}
	})

	// Run the server on port 8080
	router.Run(":8080")
}
