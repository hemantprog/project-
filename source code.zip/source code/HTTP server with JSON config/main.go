package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

// Define the structure to match the JSON input
type RequestData struct {
	Vers struct {
		Version  string `json:"version"`
		Validity string `json:"validity"`
	} `json:"Vers"`
	Token *struct { // Optional
		Token    string `json:"token"`
		Validity string `json:"validity"`
	} `json:"Token,omitempty"`
	Ap2004 struct { // VoWiFi Entitlement settings
		EntitlementStatus      string `json:"EntitlementStatus"`
		ServiceFlowURL         string `json:"ServiceFlow_URL"`
		ServiceFlowUserData    string `json:"ServiceFlow_ UserData"`
		MessageForIncompatible string `json:"MessageForIncompatible"`
		AddrStatus             string `json:"AddrStatus"`
		TCStatus               string `json:"TC_Status"`
		ProvStatus             string `json:"ProvStatus"`
	} `json:"ap2004"`
	Ap2003 struct { // Voice-over-Cellular Entitlement settings
		VoiceOverCellularEntitleInfo []struct {
			RATVoiceEntitleInfoDetails struct {
				AccessType                string `json:"AccessType"`
				HomeRoamingNWType         string `json:"HomeRoamingNWType"`
				EntitlementStatus         string `json:"EntitlementStatus"`
				NetworkVoiceIRATCapablity string `json:"NetworkVoiceIRATCapablity,omitempty"`
				MessageForIncompatible    string `json:"MessageForIncompatible,omitempty"`
			} `json:"RATVoiceEntitleInfoDetails"`
		} `json:"VoiceOverCellularEntitleInfo"`
	} `json:"ap2003"`
	Ap2005 struct { // SMSoIP Entitlement settings
		EntitlementStatus string `json:"EntitlementStatus"`
	} `json:"ap2005"`
}

func parseJSON(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method is supported", http.StatusMethodNotAllowed)
		return
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Cannot read body", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	var requestData RequestData
	err = json.Unmarshal(body, &requestData)
	if err != nil {
		http.Error(w, "Failed to parse JSON", http.StatusBadRequest)
		return
	}

	// Process the requestData and generate a response based on it
	response := fmt.Sprintf("Parsed JSON Document: %+v", requestData)
	w.Write([]byte(response))
}

func main() {
	http.HandleFunc("/parsejson", parseJSON)
	fmt.Println("Server is listening on port 8080...")
	http.ListenAndServe(":8080", nil)
}
