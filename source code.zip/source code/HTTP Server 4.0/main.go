package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"

	"github.com/coreos/go-oidc"
	"golang.org/x/oauth2"
)

// Configurations
var (
	clientID     = "your_client_id"
	clientSecret = "your_client_secret"
	redirectURL  = "http://localhost:8080/callback"
	providerURL  = "https://accounts.google.com" // Example for Google, replace with your provider
)

var (
	provider     *oidc.Provider
	oidcConfig   *oidc.Config
	oauth2Config *oauth2.Config
	verifier     *oidc.IDTokenVerifier
)

func main() {
	// Initialize OIDC provider
	var err error
	provider, err = oidc.NewProvider(context.Background(), providerURL)
	if err != nil {
		log.Fatalf("Failed to get provider: %v", err)
	}

	oidcConfig = &oidc.Config{
		ClientID: clientID,
	}

	verifier = provider.Verifier(oidcConfig)

	oauth2Config = &oauth2.Config{
		ClientID:     clientID,
		ClientSecret: clientSecret,
		RedirectURL:  redirectURL,
		Endpoint:     provider.Endpoint(),
		Scopes:       []string{oidc.ScopeOpenID, "profile", "email"},
	}

	// Set up HTTP server
	http.HandleFunc("/", handleHome)
	http.HandleFunc("/login", handleLogin)
	http.HandleFunc("/callback", handleCallback)
	http.HandleFunc("/token", handleToken) // Endpoint to initiate the token exchange

	fmt.Println("Server started at http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func handleHome(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte(`<html><body><a href="/login">Login with OAuth 2.0 / OpenID Connect</a></body></html>`))
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	authURL := oauth2Config.AuthCodeURL("state", oauth2.AccessTypeOffline)
	http.Redirect(w, r, authURL, http.StatusFound)
}

func handleCallback(w http.ResponseWriter, r *http.Request) {
	// Check state and retrieve authorization code
	if err := r.ParseForm(); err != nil {
		http.Error(w, "Failed to parse form", http.StatusBadRequest)
		return
	}

	state := r.FormValue("state")
	code := r.FormValue("code")
	if state != "state" {
		http.Error(w, "Invalid state parameter", http.StatusBadRequest)
		return
	}

	// Redirect to token exchange endpoint
	redirectURL := fmt.Sprintf("http://localhost:8080/token?code=%s&state=%s", url.QueryEscape(code), url.QueryEscape(state))
	http.Redirect(w, r, redirectURL, http.StatusFound)
}

func handleToken(w http.ResponseWriter, r *http.Request) {
	code := r.URL.Query().Get("code")
	state := r.URL.Query().Get("state")
	if state != "state" {
		http.Error(w, "Invalid state parameter", http.StatusBadRequest)
		return
	}

	// Exchange authorization code for token
	token, err := oauth2Config.Exchange(context.Background(), code)
	if err != nil {
		http.Error(w, "Failed to exchange token: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Extract and verify ID Token
	rawIDToken, ok := token.Extra("id_token").(string)
	if !ok {
		http.Error(w, "No id_token field in token", http.StatusInternalServerError)
		return
	}

	idToken, err := verifier.Verify(context.Background(), rawIDToken)
	if err != nil {
		http.Error(w, "Failed to verify ID Token: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Extract user information from ID Token
	var claims struct {
		Email string `json:"email"`
		Name  string `json:"name"`
	}
	if err := idToken.Claims(&claims); err != nil {
		http.Error(w, "Failed to extract claims: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Display user information
	resp := struct {
		AccessToken string `json:"access_token"`
		IDToken     string `json:"id_token"`
		Name        string `json:"name"`
		Email       string `json:"email"`
	}{
		AccessToken: token.AccessToken,
		IDToken:     rawIDToken,
		Name:        claims.Name,
		Email:       claims.Email,
	}
	json.NewEncoder(w).Encode(resp)
}
