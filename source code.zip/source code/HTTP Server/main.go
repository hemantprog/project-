package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

// Define a struct to represent the JSON data
type Person struct {
	Name string `json:"name"`
	Age  int    `json:"age"`
}

// Handler function for the POST request
func handlePost(w http.ResponseWriter, r *http.Request) {
	// Ensure the request method is POST
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	// Decode the JSON data from the request body
	var person Person
	err := json.NewDecoder(r.Body).Decode(&person)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Create a response message
	responseMessage := fmt.Sprintf("Hello, %s! You are %d years old.", person.Name, person.Age)

	// Write the response message as JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": responseMessage})
}

func main() {
	http.HandleFunc("/post", handlePost)
	log.Println("Server is running on port 8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
