package main

import (
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"net/http"
)

type WapProvisioningDoc struct {
	XMLName        xml.Name          `xml:"wap-provisioningdoc"`
	Version        string            `xml:"version,attr"`
	Characteristics []Characteristic `xml:"characteristic"`
}

type Characteristic struct {
	Type  string `xml:"type,attr"`
	Parms []Parm `xml:"parm"`
	SubCharacteristics []Characteristic `xml:"characteristic,omitempty"`
}

type Parm struct {
	Name  string `xml:"name,attr"`
	Value string `xml:"value,attr"`
}

func parseXML(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method is supported", http.StatusMethodNotAllowed)
		return
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Cannot read body", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	var doc WapProvisioningDoc
	err = xml.Unmarshal(body, &doc)
	if err != nil {
		http.Error(w, "Failed to parse XML", http.StatusBadRequest)
		return
	}

	// Process the doc variable and generate a response based on it
	response := fmt.Sprintf("Parsed XML Document: %+v", doc)
	w.Write([]byte(response))
}

func main() {
	http.HandleFunc("/parsexml", parseXML)
	fmt.Println("Server is listening on port 8080...")
	http.ListenAndServe(":8080", nil)
}
